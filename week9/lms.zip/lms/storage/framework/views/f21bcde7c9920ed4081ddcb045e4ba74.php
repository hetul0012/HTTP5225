;
<?php $__env->startSection('content'); ?>
    <h1>Add a Students</h1>
   <form action="<?php echo e(route('students.store')); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    <input type="text" name="fname" placeholder="First Name">
    <input type="text" name="lname" placeholder="Larst Name">
    <input type="email" name="email" placeholder="Email">
    <input type="submit" name="Add">
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\HTTP5225\week9\lms\resources\views/students/create.blade.php ENDPATH**/ ?>