

<?php $__env->startSection('content'); ?>
    <h1>Update Student</h1>
    <form action="<?php echo e(route('students.update', $student->id)); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

        <?php echo method_field('PUT'); ?>

        <input type="text" name="fname" placeholder="First Name" value="<?php echo e($student->fname); ?>">
        <input type="text" name="lname" placeholder="Last Name" value="<?php echo e($student->lname); ?>">
        <input type="email" name="email" placeholder="Email" value="<?php echo e($student->email); ?>">
        <input type="submit" value="Update">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\HTTP5225\week9\lms\resources\views/students/edit.blade.php ENDPATH**/ ?>