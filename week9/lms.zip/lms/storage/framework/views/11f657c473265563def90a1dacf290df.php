    
    <?php $__env->startSection('content'); ?>
        <h1>All Students</h1>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($student -> fname); ?> 
        <?php echo e($student -> lname); ?> 
        <?php echo e($student -> email); ?> 
        <a href="<?php echo e(route('students.edit', $student -> id )); ?>" >Edit</a>
        <form action="<?php echo e(route('students.destroy', $student->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit">Delete</button>
        </form>

        <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\HTTP5225\week9\lms\resources\views/students/index.blade.php ENDPATH**/ ?>