<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
    <div>
        <ul>
        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
            <li><a href="<?php echo e(route('students.index')); ?>">Students</a></li>
            <li><a href="<?php echo e(route('students.create')); ?>">Add Student</a></li>
        </ul>
    </div>
    <hr>
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\HTTP5225\week9\lms\resources\views/admin.blade.php ENDPATH**/ ?>